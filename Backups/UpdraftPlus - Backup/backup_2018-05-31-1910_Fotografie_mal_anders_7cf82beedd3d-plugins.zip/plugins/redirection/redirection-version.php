<?php

define( 'REDIRECTION_VERSION', '3.2' );
define( 'REDIRECTION_BUILD', 'df1f37ef3f6aba1189b89b37737a9a75' );
define( 'REDIRECTION_MIN_WP', '4.5' );
