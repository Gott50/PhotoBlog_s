# PhotoBlog_s

![PhotoBlog_s Logo](https://i.imgur.com/23yAvFQ.png)

The WordPress theme for Blogging Photographers

## Requirements
- WordPress

## Development Recommendations
- [XAMPP](https://www.apachefriends.org)

## TODOs
### Design (CSS / SCSS)
- add Colors for Text 

### Structure (PHP / HTML)
- add Menu for SocialLinks (Facebook, Instagram, etc.)
- add Footer Menu
